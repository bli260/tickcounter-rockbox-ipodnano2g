#include "plugin.h"

#define SAVE_FILE "/.rockbox/wheel_ticks.txt"

struct tick_stats {
    uint64_t total_ticks;
    uint64_t cw_ticks;
    uint64_t ccw_ticks;
};

/* Helper to convert 64-bit unsigned integer to string (since Rockbox snprintf lacks %llu) */
static void u64_to_str(uint64_t val, char *buf, size_t buf_size)
{
    char tmp[24];
    int i = 0;

    if (buf_size == 0) return;

    if (val == 0) {
        buf[0] = '0';
        buf[1] = '\0';
        return;
    }

    while (val > 0 && i < (int)(sizeof(tmp) - 1)) {
        tmp[i++] = '0' + (val % 10);
        val /= 10;
    }

    size_t pos = 0;
    while (i > 0 && pos < buf_size - 1) {
        buf[pos++] = tmp[--i];
    }
    buf[pos] = '\0';
}

/* Helper to parse 64-bit unsigned integer from string */
static uint64_t str_to_u64(const char *str)
{
    uint64_t val = 0;
    while (*str >= '0' && *str <= '9') {
        val = (val * 10) + (*str - '0');
        str++;
    }
    return val;
}

static void load_stats(struct tick_stats *stats)
{
    char buf[128];
    int fd = rb->open(SAVE_FILE, O_RDONLY);

    stats->total_ticks = 0;
    stats->cw_ticks = 0;
    stats->ccw_ticks = 0;

    if (fd >= 0) {
        int n = rb->read(fd, buf, sizeof(buf) - 1);
        rb->close(fd);
        if (n > 0) {
            buf[n] = '\0';
            char *p = buf;
            stats->total_ticks = str_to_u64(p);

            while (*p && *p != '\n') p++;
            if (*p == '\n') {
                p++;
                stats->cw_ticks = str_to_u64(p);
                while (*p && *p != '\n') p++;
                if (*p == '\n') {
                    p++;
                    stats->ccw_ticks = str_to_u64(p);
                }
            }
        }
    }
}

static void save_stats(const struct tick_stats *stats)
{
    char total_str[24], cw_str[24], ccw_str[24];
    char out_buf[128];

    u64_to_str(stats->total_ticks, total_str, sizeof(total_str));
    u64_to_str(stats->cw_ticks, cw_str, sizeof(cw_str));
    u64_to_str(stats->ccw_ticks, ccw_str, sizeof(ccw_str));

    rb->snprintf(out_buf, sizeof(out_buf), "%s\n%s\n%s\n", total_str, cw_str, ccw_str);

    int fd = rb->open(SAVE_FILE, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fd >= 0) {
        rb->write(fd, out_buf, rb->strlen(out_buf));
        rb->close(fd);
    }
}

enum plugin_status plugin_start(const void* parameter)
{
    (void)parameter;
    struct tick_stats stats;
    char num_buf[24];
    char line_buf[36];
    int button;
    bool exit_plugin = false;

    load_stats(&stats);

    while (!exit_plugin) {
        rb->lcd_clear_display();
        rb->lcd_puts(0, 0, "Click Wheel Ticks");
        rb->lcd_puts(0, 1, "-----------------");

        u64_to_str(stats.total_ticks, num_buf, sizeof(num_buf));
        rb->snprintf(line_buf, sizeof(line_buf), "Total: %s", num_buf);
        rb->lcd_puts(0, 2, line_buf);

        u64_to_str(stats.cw_ticks, num_buf, sizeof(num_buf));
        rb->snprintf(line_buf, sizeof(line_buf), "Right: %s", num_buf);
        rb->lcd_puts(0, 3, line_buf);

        u64_to_str(stats.ccw_ticks, num_buf, sizeof(num_buf));
        rb->snprintf(line_buf, sizeof(line_buf), "Left:  %s", num_buf);
        rb->lcd_puts(0, 4, line_buf);

        rb->lcd_puts(0, 6, "[MENU] Save & Exit");
        rb->lcd_puts(0, 7, "[PLAY] Reset");
        rb->lcd_update();

        button = rb->button_get(true);

        switch (button & ~BUTTON_REPEAT) {
            case BUTTON_SCROLL_FWD:
                stats.cw_ticks++;
                stats.total_ticks++;
                break;

            case BUTTON_SCROLL_BACK:
                stats.ccw_ticks++;
                stats.total_ticks++;
                break;

            case BUTTON_PLAY:
                stats.total_ticks = 0;
                stats.cw_ticks = 0;
                stats.ccw_ticks = 0;
                save_stats(&stats);
                break;

            case BUTTON_MENU:
                exit_plugin = true;
                break;

            default:
                if (rb->default_event_handler(button) == SYS_USB_CONNECTED) {
                    save_stats(&stats);
                    return PLUGIN_USB_CONNECTED;
                }
                break;
        }
    }

    save_stats(&stats);
    rb->splash(HZ / 2, "Saved!");
    return PLUGIN_OK;
}
